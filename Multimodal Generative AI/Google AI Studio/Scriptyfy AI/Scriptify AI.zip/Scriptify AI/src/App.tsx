import React, { useState, useRef, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Upload, 
  FileText, 
  Download, 
  Loader2, 
  Edit3, 
  Eye, 
  CheckCircle2, 
  AlertCircle,
  X,
  ChevronRight,
  Type,
  Maximize2,
  Minimize2,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import Markdown from 'react-markdown';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Constants & Types ---

const MODEL_NAME = "gemini-3-flash-preview";
const MAX_BASE64_SIZE = 50 * 1024 * 1024; // 50MB limit for Gemini API payload

interface ProcessedResult {
  rawText: string;
  structuredMarkdown: string;
}

// --- Helper Functions ---

async function compressImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Max dimension 2048px to keep size reasonable while maintaining OCR quality
        const MAX_DIM = 2048;
        if (width > height) {
          if (width > MAX_DIM) {
            height *= MAX_DIM / width;
            width = MAX_DIM;
          }
        } else {
          if (height > MAX_DIM) {
            width *= MAX_DIM / height;
            height = MAX_DIM;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        // Compress to JPEG with 0.8 quality
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        resolve(dataUrl.split(',')[1]);
      };
      img.onerror = reject;
    };
    reader.onerror = reject;
  });
}

// --- Components ---

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<ProcessedResult | null>(null);
  const [editableText, setEditableText] = useState<string>("");
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('preview');
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [summary, setSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const pdfContentRef = useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const generateLogo = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [
              {
                text: 'A minimalist, elegant, high-end logo for a productivity app named Scriptify AI. The logo should feature a stylized "S" that looks like a combination of a digital circuit and a fountain pen stroke. Professional, modern, emerald and stone color palette. White background, vector style.',
              },
            ],
          },
          config: {
            imageConfig: {
              aspectRatio: "1:1"
            }
          }
        });
        
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            setLogoUrl(`data:image/png;base64,${part.inlineData.data}`);
            break;
          }
        }
      } catch (err) {
        console.error("Logo generation failed:", err);
      }
    };
    generateLogo();
  }, []);

  const reset = () => {
    setFile(null);
    setPreviewUrl(null);
    setResult(null);
    setEditableText("");
    setSummary(null);
    setError(null);
    setProgress(0);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      processSelectedFile(selectedFile);
    }
  };

  const processSelectedFile = (selectedFile: File) => {
    if (!selectedFile.type.startsWith('image/') && selectedFile.type !== 'application/pdf') {
      setError("Please upload an image or PDF file.");
      return;
    }
    setFile(selectedFile);
    setPreviewUrl(URL.createObjectURL(selectedFile));
    setError(null);
  };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile) {
      processSelectedFile(droppedFile);
    }
  }, []);

  const handleProcess = async () => {
    if (!file) return;

    setIsProcessing(true);
    setError(null);
    setProgress(10);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      let base64Data = "";
      let mimeType = file.type;

      if (file.type.startsWith('image/')) {
        setProgress(15);
        base64Data = await compressImage(file);
        mimeType = 'image/jpeg'; // Compressed output is always jpeg
      } else {
        // For PDFs, we just read as is
        base64Data = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const base64 = (reader.result as string).split(',')[1];
            resolve(base64);
          };
          reader.readAsDataURL(file);
        });
      }

      // Check final size
      if (base64Data.length > MAX_BASE64_SIZE) {
        throw new Error("The file is too large to process even after compression. Please try a smaller file or a lower resolution image.");
      }

      setProgress(30);

      const prompt = `
        You are an expert OCR and document structuring assistant. 
        I am providing you with a handwritten note (image or PDF).
        
        Please perform the following steps:
        1. Extract all text from the handwriting with high precision.
        2. Clean up OCR errors, fix spelling, and improve grammar while maintaining the original meaning.
        3. Detect the logical structure:
           - Identify the main title.
           - Identify headings and subheadings.
           - Format lists (bullet points or numbered).
           - Preserve paragraphs.
           - If there are mathematical expressions, format them clearly using standard notation.
        4. Output the result in clean, well-structured Markdown.
        
        Do not include any preamble or conversational text. Just the structured Markdown.
      `;

      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: [
          {
            parts: [
              { text: prompt },
              {
                inlineData: {
                  mimeType: mimeType,
                  data: base64Data
                }
              }
            ]
          }
        ]
      });

      setProgress(90);

      const text = response.text || "";
      setResult({
        rawText: text,
        structuredMarkdown: text
      });
      setEditableText(text);
      setProgress(100);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred during processing.");
    } finally {
      setIsProcessing(false);
    }
  };

  const generatePDF = async () => {
    if (!pdfContentRef.current) return;

    setIsProcessing(true);
    setProgress(10);

    try {
      const element = pdfContentRef.current;
      
      // Temporary show element for capture
      element.style.display = 'block';
      setProgress(30);

      const canvas = await html2canvas(element, {
        scale: 2, // Higher quality
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      setProgress(70);

      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
      });

      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      // Handle multi-page if content is long
      let heightLeft = pdfHeight;
      let position = 0;
      const pageHeight = pdf.internal.pageSize.getHeight();

      pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, pdfHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - pdfHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, pdfHeight);
        heightLeft -= pageHeight;
      }

      // Add page numbers
      const pageCount = pdf.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        pdf.setPage(i);
        pdf.setFontSize(10);
        pdf.setTextColor(150);
        pdf.text(`Page ${i} of ${pageCount}`, pdfWidth / 2, pageHeight - 10, { align: 'center' });
      }

      setProgress(90);
      pdf.save(`${file?.name.split('.')[0] || 'document'}_scriptified.pdf`);
      
      // Hide element again
      element.style.display = 'none';
      setProgress(100);
    } catch (err) {
      console.error("PDF Generation Error:", err);
      setError("Failed to generate PDF. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSummarize = async () => {
    if (!editableText) return;

    setIsSummarizing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `
        Please provide a concise and professional summary of the following notes. 
        Use Markdown for formatting. Focus on the key points and action items if any.
        
        Notes:
        ${editableText}
      `;

      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: [{ parts: [{ text: prompt }] }]
      });

      setSummary(response.text || "Could not generate summary.");
    } catch (err: any) {
      console.error(err);
      setError("Failed to generate summary: " + (err.message || "Unknown error"));
    } finally {
      setIsSummarizing(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-x-hidden">
      <div className="fancy-bg" />
      
      {/* Header */}
      <header className="border-b border-white/20 bg-white/40 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <motion.div 
              whileHover={{ rotate: 180 }}
              transition={{ duration: 0.5 }}
              className="w-10 h-10 bg-stone-900 rounded-xl flex items-center justify-center shadow-lg overflow-hidden"
            >
              {logoUrl ? (
                <img src={logoUrl} alt="Logo" className="w-full h-full object-cover" />
              ) : (
                <Type className="text-white w-6 h-6" />
              )}
            </motion.div>
            <h1 className="text-2xl font-serif font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-stone-900 to-stone-600">Scriptify AI</h1>
          </div>
          
          {result && (
            <div className="flex items-center gap-3">
              <button 
                onClick={reset}
                className="text-sm font-medium text-stone-500 hover:text-stone-900 transition-colors"
              >
                Start Over
              </button>
              <button 
                onClick={generatePDF}
                className="flex items-center gap-2 bg-stone-900 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-stone-800 transition-all shadow-sm"
              >
                <Download className="w-4 h-4" />
                Download PDF
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6 md:p-10">
        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div 
              key="upload"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ type: "spring", damping: 20, stiffness: 100 }}
              className="max-w-2xl mx-auto"
            >
              <div className="text-center mb-12">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <h2 className="text-6xl font-serif font-bold mb-6 tracking-tight leading-tight">
                    Your notes, <br />
                    <span className="italic text-emerald-600">perfectly structured.</span>
                  </h2>
                  <p className="text-stone-500 text-xl max-w-xl mx-auto leading-relaxed">
                    The most elegant way to transform handwritten thoughts into professional digital documents.
                  </p>
                </motion.div>
              </div>

              <motion.div 
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onDragOver={(e) => e.preventDefault()}
                onDrop={onDrop}
                className={cn(
                  "relative group cursor-pointer",
                  "border-2 border-dashed rounded-[2rem] p-10 transition-all duration-500",
                  file ? "border-emerald-500 bg-emerald-50/30" : "border-stone-200 hover:border-emerald-300 bg-white/50 backdrop-blur-sm shadow-xl hover:shadow-2xl"
                )}
                onClick={() => !isProcessing && fileInputRef.current?.click()}
              >
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  className="hidden" 
                  accept="image/*,application/pdf"
                />
                
                <div className="flex flex-col items-center gap-6">
                  {file ? (
                    <div className="flex flex-col items-center">
                      <motion.div 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-20 h-20 bg-stone-900 rounded-2xl flex items-center justify-center mb-4 shadow-2xl"
                      >
                        <FileText className="text-white w-10 h-10" />
                      </motion.div>
                      <p className="text-lg font-medium text-stone-900">{file.name}</p>
                      <p className="text-sm text-stone-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  ) : (
                    <>
                      <div className="w-20 h-20 bg-stone-100 rounded-2xl flex items-center justify-center group-hover:bg-emerald-50 transition-colors duration-500">
                        <Upload className="text-stone-400 group-hover:text-emerald-500 w-8 h-8 transition-colors duration-500" />
                      </div>
                      <div className="text-center">
                        <p className="text-xl font-medium text-stone-900 mb-1">Drop your notes here</p>
                        <p className="text-stone-500">or click to browse your files</p>
                      </div>
                    </>
                  )}
                </div>

                {file && !isProcessing && (
                  <button 
                    onClick={(e) => { e.stopPropagation(); reset(); }}
                    className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-sm border border-stone-100 hover:bg-stone-50 transition-colors"
                  >
                    <X className="w-4 h-4 text-stone-500" />
                  </button>
                )}
              </motion.div>

              {error && (
                <div className="mt-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-start gap-3 text-red-700">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                  <p className="text-sm">{error}</p>
                </div>
              )}

              <div className="mt-16 flex justify-center">
                <button
                  disabled={!file || isProcessing}
                  onClick={handleProcess}
                  className={cn(
                    "relative overflow-hidden group px-12 py-5 rounded-full font-bold text-xl transition-all duration-500",
                    !file || isProcessing 
                      ? "bg-stone-100 text-stone-400 cursor-not-allowed" 
                      : "bg-stone-900 text-white hover:bg-emerald-600 shadow-2xl hover:shadow-emerald-200 hover:-translate-y-1"
                  )}
                >
                  <span className="relative z-10 flex items-center gap-2">
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Processing... {progress}%
                      </>
                    ) : (
                      <>
                        Transcribe & Format
                        <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </span>
                  {isProcessing && (
                    <motion.div 
                      className="absolute bottom-0 left-0 h-1 bg-emerald-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                    />
                  )}
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="result"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-10 h-[calc(100vh-14rem)]"
            >
              {/* Left Side: Original Image Preview */}
              <div className="flex flex-col gap-6">
                <div className="flex items-center justify-between px-2">
                  <h3 className="font-serif font-bold text-2xl flex items-center gap-3">
                    <Maximize2 className="w-6 h-6 text-emerald-600" />
                    Source
                  </h3>
                  <span className="text-xs font-mono text-stone-400 uppercase tracking-[0.2em]">{file?.name}</span>
                </div>
                <div className="flex-1 glass-card rounded-[2.5rem] overflow-hidden relative group">
                  {file?.type === 'application/pdf' ? (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-stone-50 text-stone-400">
                      <FileText className="w-20 h-20 mb-6 opacity-20" />
                      <p className="font-medium">PDF Preview</p>
                    </div>
                  ) : (
                    <img 
                      src={previewUrl!} 
                      alt="Original note" 
                      className="w-full h-full object-contain p-8"
                      referrerPolicy="no-referrer"
                    />
                  )}
                </div>
              </div>

              {/* Right Side: Editor / Preview */}
              <div className="flex flex-col gap-6">
                <div className="flex items-center justify-between px-2">
                  <div className="flex bg-stone-200/50 backdrop-blur-sm p-1.5 rounded-full">
                    <button 
                      onClick={() => setViewMode('preview')}
                      className={cn(
                        "px-6 py-2 rounded-full text-sm font-bold transition-all duration-300",
                        viewMode === 'preview' ? "bg-white text-stone-900 shadow-md" : "text-stone-500 hover:text-stone-700"
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <Eye className="w-4 h-4" />
                        Preview
                      </div>
                    </button>
                    <button 
                      onClick={() => setViewMode('edit')}
                      className={cn(
                        "px-6 py-2 rounded-full text-sm font-bold transition-all duration-300",
                        viewMode === 'edit' ? "bg-white text-stone-900 shadow-md" : "text-stone-500 hover:text-stone-700"
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <Edit3 className="w-4 h-4" />
                        Edit
                      </div>
                    </button>
                  </div>
                  <div className="flex items-center gap-2 text-emerald-600 text-sm font-bold bg-emerald-50 px-4 py-2 rounded-full">
                    <CheckCircle2 className="w-4 h-4" />
                    AI Verified
                  </div>
                </div>

                <div className="flex-1 glass-card rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col">
                  <div className="flex items-center justify-between px-8 py-4 border-b border-stone-100 bg-white/50">
                    <span className="text-xs font-bold text-stone-400 uppercase tracking-[0.2em]">Structured Output</span>
                    <button 
                      onClick={handleSummarize}
                      disabled={isSummarizing}
                      className={cn(
                        "flex items-center gap-2 px-4 py-2 rounded-full text-xs font-black transition-all duration-300",
                        summary 
                          ? "bg-emerald-500 text-white shadow-lg shadow-emerald-200" 
                          : "bg-stone-900 text-white hover:bg-emerald-600 disabled:opacity-50 shadow-lg"
                      )}
                    >
                      {isSummarizing ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : (
                        <Sparkles className="w-3 h-3" />
                      )}
                      {summary ? "Summary Ready" : "Summarize"}
                    </button>
                  </div>

                  <div className="flex-1 overflow-hidden flex flex-col">
                    {summary && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        className="bg-emerald-50/20 border-b border-emerald-100 p-10 relative group"
                      >
                        <div className="flex items-center justify-between mb-6">
                          <h4 className="text-lg font-bold text-emerald-800 flex items-center gap-3">
                            <Sparkles className="w-5 h-5" />
                            AI Insight
                          </h4>
                          <button 
                            onClick={() => setSummary(null)}
                            className="text-emerald-400 hover:text-emerald-600 transition-colors p-2 hover:bg-emerald-100 rounded-full"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="markdown-body text-base">
                          <Markdown>{summary}</Markdown>
                        </div>
                      </motion.div>
                    )}

                    {viewMode === 'edit' ? (
                      <textarea
                        value={editableText}
                        onChange={(e) => setEditableText(e.target.value)}
                        className="flex-1 p-10 font-mono text-base resize-none focus:outline-none bg-stone-50/30"
                        placeholder="Edit the extracted text here..."
                      />
                    ) : (
                      <div className="flex-1 overflow-y-auto p-10 md:p-16">
                        <div className="markdown-body">
                          <Markdown>{editableText}</Markdown>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Hidden PDF Export Template */}
      <div style={{ position: 'absolute', left: '-9999px', top: '-9999px' }}>
        <div 
          ref={pdfContentRef} 
          style={{ width: '210mm', padding: '25mm', backgroundColor: 'white' }}
          className="markdown-body"
        >
          <div className="mb-12 border-b-2 pb-6" style={{ borderColor: '#1c1917' }}>
            <h1 style={{ fontSize: '32pt', marginBottom: '8pt', color: '#1c1917' }} className="font-serif font-bold">
              {file?.name.split('.')[0].replace(/[-_]/g, ' ') || 'Scriptify AI Document'}
            </h1>
            <p className="font-sans text-sm uppercase tracking-widest" style={{ color: '#78716c' }}>
              Generated by Scriptify AI • {new Date().toLocaleDateString()}
            </p>
          </div>

          {summary && (
            <div className="mb-12 p-8 rounded-2xl border" style={{ backgroundColor: '#fafaf9', borderColor: '#f5f5f4' }}>
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2" style={{ color: '#1c1917' }}>
                Executive Summary
              </h2>
              <div className="leading-relaxed" style={{ color: '#44403c' }}>
                <Markdown>{summary}</Markdown>
              </div>
            </div>
          )}

          <div style={{ color: '#1c1917' }}>
            <Markdown>{editableText}</Markdown>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 border-t border-stone-100">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-stone-400 text-sm">© 2024 Scriptify AI. Powered by Gemini 3 Flash.</p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-stone-400 hover:text-stone-900 text-sm transition-colors">Privacy</a>
            <a href="#" className="text-stone-400 hover:text-stone-900 text-sm transition-colors">Terms</a>
            <a href="#" className="text-stone-400 hover:text-stone-900 text-sm transition-colors">Help</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
