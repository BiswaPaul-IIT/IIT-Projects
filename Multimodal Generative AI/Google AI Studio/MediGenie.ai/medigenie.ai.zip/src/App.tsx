/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Paperclip, 
  Mic, 
  Stethoscope, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Activity,
  FileText,
  User,
  X,
  ChevronRight,
  Loader2,
  Sparkles,
  Cpu
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { cn } from './lib/utils';
import { GoogleGenAI } from "@google/genai";

// Initialize AI
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

interface Message {
  role: 'user' | 'model';
  text: string;
  attachments?: { data: string; mimeType: string; name: string }[];
}

interface IntakeSummary {
  summary: string;
  observations: string;
  possibleConditions: string[];
  riskLevel: 'Low' | 'Moderate' | 'High' | 'Unknown';
  nextSteps: string[];
  extractedData: {
    symptoms: string[];
    duration: string;
    severity: string;
    affectedAreas: string[];
    medicalHistory: string;
  };
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'model', 
      text: "### INITIALIZING NEURAL LINK...\n\nHello, I'm **MediGenie.ai**, your advanced medical intake assistant. I'm here to help collect information about your health concerns to prepare for your consultation. \n\n**What symptoms are you experiencing today?**" 
    }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [attachments, setAttachments] = useState<{ data: string; mimeType: string; name: string }[]>([]);
  const [summary, setSummary] = useState<IntakeSummary | null>(null);
  const [showSummary, setShowSummary] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachments(prev => [...prev, {
          data: reader.result as string,
          mimeType: file.type,
          name: file.name
        }]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleSend = async () => {
    if (!input.trim() && attachments.length === 0) return;

    const userMessage: Message = {
      role: 'user',
      text: input,
      attachments: attachments.length > 0 ? [...attachments] : undefined
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setAttachments([]);
    setIsProcessing(true);

    try {
      const systemInstruction = `You are MediGenie.ai, a futuristic AI Medical Intake Assistant. Your job is to help collect and summarize patient information safely.
      
      - Extract key info: symptoms, duration, severity, affected areas, and medical history.
      - Provide a patient summary and observations, suggest possible conditions (non-diagnostic), risk level, and next steps.
      - Ask follow-up questions if information is missing.
      - ALWAYS include this disclaimer: "This is not a medical diagnosis. Please consult a qualified healthcare professional."
      - Be empathetic, professional, and clear.
      - If the user provides images (like a rash or wound) or audio (like a cough or voice description), analyze them to add to the observations.
      - Format your response clearly. Use markdown.
      - Use a futuristic, high-tech tone.`;

      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const currentParts: any[] = [{ text: input }];
      attachments.forEach(att => {
        currentParts.push({
          inlineData: {
            data: att.data.split(',')[1],
            mimeType: att.mimeType
          }
        });
      });

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          ...history,
          { role: 'user', parts: currentParts }
        ],
        config: {
          systemInstruction,
        }
      });

      const modelText = response.text || "I'm sorry, I couldn't generate a response.";
      setMessages(prev => [...prev, { role: 'model', text: modelText }]);

      // Generate structured summary in background
      updateSummary([...messages, userMessage, { role: 'model', text: modelText }]);

    } catch (error) {
      console.error("Error processing intake:", error);
      setMessages(prev => [...prev, { role: 'model', text: "I'm sorry, I encountered an error processing your information. Please try again." }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const updateSummary = async (chatHistory: Message[]) => {
    try {
      const prompt = `Based on the conversation history, provide a structured summary of the patient's intake.
      Return the response in JSON format with the following structure:
      {
        "summary": "string",
        "observations": "string",
        "possibleConditions": ["string"],
        "riskLevel": "Low" | "Moderate" | "High" | "Unknown",
        "nextSteps": ["string"],
        "extractedData": {
          "symptoms": ["string"],
          "duration": "string",
          "severity": "string",
          "affectedAreas": ["string"],
          "medicalHistory": "string"
        }
      }`;

      const history = chatHistory.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          ...history,
          { role: 'user', parts: [{ text: prompt }] }
        ],
        config: {
          responseMimeType: "application/json"
        }
      });

      const summaryData = JSON.parse(result.text || "{}");
      setSummary(summaryData);
    } catch (e) {
      console.error("Failed to update summary", e);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#020617] text-slate-100 font-sans selection:bg-blue-500/30 overflow-hidden relative">
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute inset-0 bg-grid-white opacity-20"></div>
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/10 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
        
        {/* Scanning Line Background */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-500/5 to-transparent h-[2px] w-full animate-[scan_8s_linear_infinite]"></div>
      </div>

      {/* Header */}
      <header className="bg-slate-950/50 backdrop-blur-xl border-b border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-xl blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200"></div>
            <div className="relative w-10 h-10 bg-slate-900 border border-white/10 rounded-xl flex items-center justify-center text-blue-400 shadow-2xl">
              <Cpu size={22} className="animate-pulse" />
              <div className="absolute -top-1 -right-1">
                <Sparkles size={12} className="text-amber-400" />
              </div>
            </div>
          </div>
          <div>
            <h1 className="font-display font-black text-2xl tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-cyan-300 to-blue-500">MediGenie.ai</h1>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]"></div>
              <p className="text-[9px] text-slate-400 font-black uppercase tracking-[0.3em]">Neural Link Active</p>
            </div>
          </div>
        </div>
        
        <button 
          onClick={() => setShowSummary(!showSummary)}
          className={cn(
            "flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all duration-300 border",
            showSummary 
              ? "bg-blue-500 text-white border-blue-400 shadow-[0_0_20px_rgba(59,130,246,0.4)]" 
              : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:border-white/20"
          )}
        >
          <Activity size={16} className={showSummary ? "animate-pulse" : ""} />
          {showSummary ? "HUD Online" : "View HUD"}
        </button>
      </header>

      <main className="flex-1 flex overflow-hidden relative z-10">
        {/* Chat Area */}
        <div className={cn(
          "flex-1 flex flex-col transition-all duration-500 ease-in-out relative",
          showSummary ? "mr-[420px]" : "mr-0"
        )}>
          {/* Disclaimer */}
          <div className="bg-amber-500/5 backdrop-blur-md border-b border-amber-500/10 px-6 py-3 flex items-start gap-3">
            <AlertCircle className="text-amber-500 shrink-0 mt-0.5" size={16} />
            <p className="text-[10px] text-amber-200/70 leading-relaxed font-bold uppercase tracking-wider">
              <span className="text-amber-400 font-black mr-1">Protocol:</span> This system provides informational summaries only. Consult a human specialist for diagnosis.
            </p>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-8 scroll-smooth custom-scrollbar">
            {messages.map((msg, idx) => (
              <motion.div
                initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20, scale: 0.98 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                key={idx}
                className={cn(
                  "flex gap-4 max-w-3xl",
                  msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
                )}
              >
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-1 border backdrop-blur-md transition-all duration-500",
                  msg.role === 'user' 
                    ? "bg-white/5 border-white/10 text-slate-400" 
                    : "bg-blue-500/10 border-blue-500/20 text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.1)]"
                )}>
                  {msg.role === 'user' ? <User size={20} /> : <Cpu size={20} className="animate-pulse" />}
                </div>
                
                <div className="space-y-3">
                  <div className={cn(
                    "px-6 py-4 rounded-2xl shadow-2xl text-sm leading-relaxed border backdrop-blur-md relative overflow-hidden group",
                    msg.role === 'user' 
                      ? "bg-blue-600/20 border-blue-500/30 text-blue-50 rounded-tr-none" 
                      : "bg-slate-900/60 border-white/10 text-slate-200 rounded-tl-none"
                  )}>
                    {/* Subtle message bubble glow */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                    
                    <div className="prose prose-invert prose-sm max-w-none font-sans">
                      <ReactMarkdown>
                        {msg.text}
                      </ReactMarkdown>
                    </div>
                  </div>
                  
                  {msg.attachments && (
                    <div className="flex flex-wrap gap-3 mt-3">
                      {msg.attachments.map((att, i) => (
                        <div key={i} className="bg-slate-900/60 border border-white/10 rounded-xl p-2.5 flex items-center gap-3 shadow-lg backdrop-blur-md group hover:border-blue-500/50 transition-colors">
                          {att.mimeType.startsWith('image/') ? (
                            <div className="relative w-12 h-12 rounded-lg overflow-hidden">
                              <img src={att.data} alt="attachment" className="w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-blue-500/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            </div>
                          ) : (
                            <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center border border-white/5">
                              <FileText size={20} className="text-slate-400" />
                            </div>
                          )}
                          <div className="flex flex-col">
                            <span className="text-[11px] font-black text-slate-300 truncate max-w-[120px] uppercase tracking-tight">{att.name}</span>
                            <span className="text-[9px] text-slate-500 uppercase tracking-widest font-black">Data Stream</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
            {isProcessing && (
              <div className="flex gap-4 mr-auto">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                  <Loader2 size={20} className="animate-spin" />
                </div>
                <div className="bg-slate-900/60 border border-white/10 px-6 py-4 rounded-2xl rounded-tl-none shadow-2xl backdrop-blur-md">
                  <div className="flex gap-2">
                    <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '200ms' }}></span>
                    <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '400ms' }}></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-6 bg-slate-950/50 backdrop-blur-xl border-t border-white/5">
            <AnimatePresence>
              {attachments.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="flex flex-wrap gap-3 mb-6"
                >
                  {attachments.map((att, i) => (
                    <div key={i} className="relative group">
                      <div className="bg-white/5 border border-white/10 rounded-xl p-2.5 pr-10 flex items-center gap-3 backdrop-blur-md">
                        {att.mimeType.startsWith('image/') ? (
                          <img src={att.data} alt="preview" className="w-10 h-10 object-cover rounded-lg border border-white/10" />
                        ) : (
                          <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center border border-white/5">
                            <FileText size={18} className="text-slate-400" />
                          </div>
                        )}
                        <div className="flex flex-col">
                          <span className="text-[11px] font-black text-slate-300 truncate max-w-[140px] uppercase tracking-tight">{att.name}</span>
                          <span className="text-[9px] text-slate-500 uppercase tracking-widest font-black">Ready for Upload</span>
                        </div>
                        <button 
                          onClick={() => removeAttachment(i)}
                          className="absolute right-2 top-2 w-6 h-6 bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white rounded-lg flex items-center justify-center transition-all"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex items-end gap-4 bg-white/5 border border-white/10 rounded-2xl p-3 focus-within:border-blue-500/50 focus-within:ring-4 focus-within:ring-blue-500/5 transition-all shadow-2xl relative group">
              <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-focus-within:opacity-100 transition-opacity rounded-2xl pointer-events-none"></div>
              
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="p-3 text-slate-400 hover:text-blue-400 hover:bg-white/5 rounded-xl transition-all relative z-10"
              >
                <Paperclip size={22} />
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                className="hidden" 
                multiple
              />
              
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Initialize neural link... type your query"
                className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-3 resize-none max-h-32 min-h-[48px] text-slate-200 placeholder:text-slate-600 font-mono relative z-10"
                rows={1}
              />
              
              <button 
                onClick={handleSend}
                disabled={!input.trim() && attachments.length === 0 || isProcessing}
                className={cn(
                  "p-3 rounded-xl transition-all duration-300 flex items-center justify-center relative z-10",
                  input.trim() || attachments.length > 0 
                    ? "bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)] hover:shadow-[0_0_25px_rgba(37,99,235,0.6)]" 
                    : "bg-white/5 text-slate-600 cursor-not-allowed"
                )}
              >
                <Send size={22} />
              </button>
            </div>
            <div className="flex justify-between items-center mt-4 px-2">
              <p className="text-[9px] text-slate-600 font-black uppercase tracking-[0.4em]">
                Neural Link v4.0.2 // Secure Channel
              </p>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5">
                  <div className="w-1 h-1 bg-blue-500 rounded-full shadow-[0_0_5px_rgba(59,130,246,1)]"></div>
                  <span className="text-[9px] text-slate-600 font-black uppercase tracking-widest">Encrypted</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-1 h-1 bg-blue-500 rounded-full shadow-[0_0_5px_rgba(59,130,246,1)]"></div>
                  <span className="text-[9px] text-slate-600 font-black uppercase tracking-widest">AI Verified</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Summary Panel (HUD) */}
        <AnimatePresence>
          {showSummary && (
            <motion.aside
              initial={{ x: 420, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 420, opacity: 0 }}
              transition={{ type: 'spring', damping: 28, stiffness: 220 }}
              className="fixed top-[73px] right-0 bottom-0 w-[420px] bg-slate-950/80 backdrop-blur-3xl border-l border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] z-20 overflow-y-auto custom-scrollbar"
            >
              {/* HUD Scanning Line */}
              <div className="absolute inset-0 pointer-events-none overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-[1px] bg-blue-500/20 animate-[scan_4s_linear_infinite]"></div>
                <div className="absolute inset-0 bg-grid-white opacity-5"></div>
              </div>

              <div className="p-8 space-y-10 relative z-10">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <h2 className="text-2xl font-display font-black tracking-tighter flex items-center gap-3 text-white">
                      <div className="w-2 h-8 bg-blue-500 rounded-full shadow-[0_0_15px_rgba(59,130,246,0.6)]"></div>
                      PATIENT HUD
                    </h2>
                    <span className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em] mt-1 ml-5">Real-time Analysis</span>
                  </div>
                  <button onClick={() => setShowSummary(false)} className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 transition-all border border-white/5">
                    <X size={20} />
                  </button>
                </div>

                {!summary ? (
                  <div className="flex flex-col items-center justify-center py-32 text-center space-y-8">
                    <div className="relative">
                      <div className="absolute inset-0 bg-blue-500/20 blur-3xl animate-pulse"></div>
                      <div className="relative w-24 h-24 bg-slate-900 border border-white/10 rounded-[2rem] flex items-center justify-center text-blue-400 shadow-2xl">
                        <Loader2 size={48} className="animate-spin" />
                        <div className="absolute inset-0 rounded-[2rem] border-2 border-blue-500/20 animate-ping"></div>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h3 className="font-black text-white uppercase tracking-[0.3em] text-xs">Scanning Data Streams...</h3>
                      <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest leading-relaxed max-w-[240px]">Awaiting sufficient input to initialize clinical summary.</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-10">
                    {/* Risk Level HUD */}
                    <div className="relative group">
                      <div className={cn(
                        "absolute -inset-0.5 rounded-3xl blur opacity-30 transition duration-1000",
                        summary.riskLevel === 'Low' ? "bg-emerald-500" :
                        summary.riskLevel === 'Moderate' ? "bg-amber-500" :
                        summary.riskLevel === 'High' ? "bg-red-500" :
                        "bg-blue-500"
                      )}></div>
                      <div className="relative bg-slate-900/60 border border-white/10 rounded-3xl p-6 backdrop-blur-md">
                        <div className="flex items-center justify-between mb-6">
                          <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">Triage Status</span>
                          <div className={cn(
                            "px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest border shadow-lg",
                            summary.riskLevel === 'Low' ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" :
                            summary.riskLevel === 'Moderate' ? "bg-amber-500/10 border-amber-500/30 text-amber-400" :
                            summary.riskLevel === 'High' ? "bg-red-500/10 border-red-500/30 text-red-400 animate-pulse" :
                            "bg-blue-500/10 border-blue-500/30 text-blue-400"
                          )}>
                            {summary.riskLevel} Priority
                          </div>
                        </div>
                        <p className="text-sm text-slate-200 leading-relaxed font-bold italic font-display">
                          "{summary.summary}"
                        </p>
                      </div>
                    </div>

                    {/* Technical Data Grid */}
                    <div className="grid grid-cols-2 gap-5">
                      <div className="bg-slate-900/40 border border-white/5 rounded-2xl p-5 backdrop-blur-md group hover:border-blue-500/30 transition-all">
                        <div className="flex items-center gap-2 text-blue-400 mb-4">
                          <Activity size={16} />
                          <span className="text-[10px] font-black uppercase tracking-widest">Symptoms</span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {summary.extractedData.symptoms.map((s, i) => (
                            <span key={i} className="text-[9px] bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2.5 py-1 rounded-md font-black uppercase tracking-widest">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="bg-slate-900/40 border border-white/5 rounded-2xl p-5 backdrop-blur-md group hover:border-indigo-500/30 transition-all">
                        <div className="flex items-center gap-2 text-indigo-400 mb-4">
                          <Clock size={16} />
                          <span className="text-[10px] font-black uppercase tracking-widest">Duration</span>
                        </div>
                        <p className="text-xs font-black text-white uppercase tracking-widest">{summary.extractedData.duration || 'N/A'}</p>
                      </div>
                    </div>

                    {/* Observations HUD Section */}
                    <section className="space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="h-px flex-1 bg-gradient-to-r from-transparent to-white/10"></div>
                        <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">Clinical Data</h3>
                        <div className="h-px flex-1 bg-gradient-to-l from-transparent to-white/10"></div>
                      </div>
                      <div className="bg-slate-900/40 border border-white/10 rounded-2xl p-6 backdrop-blur-md relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-1 h-full bg-blue-500/50"></div>
                        <p className="text-sm text-slate-300 leading-relaxed font-bold font-display">
                          {summary.observations}
                        </p>
                      </div>
                    </section>

                    {/* Potential Considerations HUD Section */}
                    <section className="space-y-4">
                      <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 text-center">Neural Predictions</h3>
                      <div className="space-y-3">
                        {summary.possibleConditions.map((cond, i) => (
                          <div key={i} className="flex items-center gap-4 p-4 bg-white/5 border border-white/5 rounded-2xl hover:bg-white/10 transition-all group relative overflow-hidden">
                            <div className="absolute inset-y-0 left-0 w-1 bg-blue-500 transform -translate-x-full group-hover:translate-x-0 transition-transform"></div>
                            <div className="w-1.5 h-1.5 rounded-full bg-blue-500 group-hover:shadow-[0_0_10px_rgba(59,130,246,1)] transition-all" />
                            <span className="text-sm font-black text-slate-200 uppercase tracking-widest font-display">{cond}</span>
                          </div>
                        ))}
                      </div>
                    </section>

                    {/* Next Steps HUD Section */}
                    <section className="space-y-4">
                      <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 text-center">Action Protocols</h3>
                      <div className="space-y-3">
                        {summary.nextSteps.map((step, i) => (
                          <div key={i} className="flex items-start gap-4 p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl group hover:bg-emerald-500/10 transition-all">
                            <CheckCircle2 size={18} className="text-emerald-500 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
                            <span className="text-sm font-black text-emerald-100/80 leading-relaxed uppercase tracking-tight">{step}</span>
                          </div>
                        ))}
                      </div>
                    </section>

                    <div className="pt-10 border-t border-white/10">
                      <div className="flex items-start gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
                        <AlertCircle size={16} className="text-slate-500 shrink-0 mt-0.5" />
                        <p className="text-[10px] leading-relaxed font-black text-slate-500 uppercase tracking-[0.2em]">
                          Automated summary. Verification by human medical personnel required.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </main>

      <style>{`
        @keyframes scan {
          from { transform: translateY(-100%); }
          to { transform: translateY(1000%); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
}
