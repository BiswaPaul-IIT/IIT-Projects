import { GoogleGenAI, Modality, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface ExplanationResult {
  text: string;
  imageUrl: string;
  audioUrl: string;
}

function encodeWAV(samples: Uint8Array, sampleRate: number = 24000): Blob {
  const buffer = new ArrayBuffer(44 + samples.length);
  const view = new DataView(buffer);

  /* RIFF identifier */
  view.setUint32(0, 0x52494646, false); // "RIFF"
  /* file length */
  view.setUint32(4, 36 + samples.length, true);
  /* RIFF type */
  view.setUint32(8, 0x57415645, false); // "WAVE"
  /* format chunk identifier */
  view.setUint32(12, 0x666d7420, false); // "fmt "
  /* format chunk length */
  view.setUint32(16, 16, true);
  /* sample format (raw) */
  view.setUint16(20, 1, true);
  /* channel count */
  view.setUint16(22, 1, true);
  /* sample rate */
  view.setUint32(24, sampleRate, true);
  /* byte rate (sample rate * block align) */
  view.setUint32(28, sampleRate * 2, true);
  /* block align (channel count * bytes per sample) */
  view.setUint16(32, 2, true);
  /* bits per sample */
  view.setUint16(34, 16, true);
  /* data chunk identifier */
  view.setUint32(36, 0x64617461, false); // "data"
  /* data chunk length */
  view.setUint32(40, samples.length, true);

  // Copy samples
  const output = new Uint8Array(buffer, 44);
  output.set(samples);

  return new Blob([buffer], { type: 'audio/wav' });
}

export async function explainConcept(concept: string): Promise<ExplanationResult> {
  // Run all three generations in parallel with individual error handling
  const [textResult, imageResult, audioResult] = await Promise.allSettled([
    // 1. Generate Text Explanation (with fallback)
    (async () => {
      try {
        return await ai.models.generateContent({
          model: "gemini-3.1-pro-preview",
          contents: `Explain the concept of "${concept}" in a clear, educational way. Use Markdown formatting. Keep it engaging and suitable for a student.`,
          config: {
            systemInstruction: "You are a world-class virtual teacher. Your explanations are clear, concise, and use analogies where helpful.",
          }
        });
      } catch (e) {
        console.warn("Pro model failed, falling back to Flash:", e);
        return await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: `Explain the concept of "${concept}" in a clear, educational way. Use Markdown formatting. Keep it engaging and suitable for a student.`,
          config: {
            systemInstruction: "You are a world-class virtual teacher. Your explanations are clear, concise, and use analogies where helpful.",
          }
        });
      }
    })(),

    // 2. Generate Illustration (using gemini-2.5-flash-image)
    ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: `A clear, educational diagram or illustration explaining ${concept}. Professional, clean, and informative style.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9",
        },
      },
    }),

    // 3. Generate Narrated Audio (TTS) with retry logic
    (async () => {
      const audioPrompt = `In brief, ${concept} is an important concept. Here is a quick summary of what it means for a student.`;
      try {
        return await ai.models.generateContent({
          model: "gemini-2.5-flash-preview-tts",
          contents: [{ parts: [{ text: audioPrompt }] }],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: 'Kore' },
              },
            },
          },
        });
      } catch (e) {
        console.warn("Primary audio generation failed, retrying with minimal prompt:", e);
        // Minimal fallback prompt
        return await ai.models.generateContent({
          model: "gemini-2.5-flash-preview-tts",
          contents: [{ parts: [{ text: `Let's learn about ${concept}.` }] }],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: 'Kore' },
              },
            },
          },
        });
      }
    })()
  ]);

  // Process Text
  let explanationText = "Sorry, I couldn't generate a text explanation at this moment.";
  if (textResult.status === 'fulfilled') {
    explanationText = textResult.value.text || explanationText;
  } else {
    console.error("Text generation failed:", textResult.reason);
  }

  // Process Image
  let imageUrl = "";
  if (imageResult.status === 'fulfilled') {
    for (const part of imageResult.value.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        break;
      }
    }
  } else {
    console.error("Image generation failed:", imageResult.reason);
  }

  // Process Audio (PCM to WAV)
  let audioUrl = "";
  if (audioResult.status === 'fulfilled') {
    const base64Audio = audioResult.value.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      try {
        // Clean base64 string and decode
        const cleanedBase64 = base64Audio.replace(/\s/g, '');
        const binary = atob(cleanedBase64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        const blob = encodeWAV(bytes, 24000);
        audioUrl = URL.createObjectURL(blob);
        console.log("Audio generated successfully, URL created.");
      } catch (e) {
        console.error("Failed to process audio data:", e);
      }
    } else {
      console.warn("Audio response fulfilled but no data found in parts.");
    }
  } else {
    console.error("Audio generation failed:", audioResult.reason);
  }

  // If everything failed, throw a combined error
  if (textResult.status === 'rejected' && imageResult.status === 'rejected' && audioResult.status === 'rejected') {
    throw new Error("All AI services failed. Please check your connection or try a different concept.");
  }

  return {
    text: explanationText,
    imageUrl,
    audioUrl,
  };
}
