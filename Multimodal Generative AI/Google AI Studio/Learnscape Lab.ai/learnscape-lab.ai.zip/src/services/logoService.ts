import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateLogo(): Promise<string> {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          text: "A professional, minimal vector-style logo for 'LearnScape Lab.ai'. The design features an abstract open book that transforms into a layered knowledge landscape. Subtle, glowing neural network and AI circuitry patterns are integrated into the layers. Color palette: a smooth gradient of deep blue, vibrant teal, and electric purple, with a sharp accent of neon green. Typography: Sleek, modern sans-serif font, with 'LearnScape' in bold and 'Lab.ai' in a lighter weight. The logo should look high-end, futuristic, and tech-oriented. White background for a clean look.",
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1",
      },
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return "";
}
