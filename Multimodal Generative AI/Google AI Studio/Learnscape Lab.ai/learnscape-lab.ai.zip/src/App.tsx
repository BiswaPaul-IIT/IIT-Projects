import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, BookOpen, Image as ImageIcon, Volume2, Loader2, Sparkles, ArrowRight, Play, Pause } from 'lucide-react';
import Markdown from 'react-markdown';
import { explainConcept, ExplanationResult } from './services/geminiService';
import { generateLogo } from './services/logoService';
import { cn } from './lib/utils';

export default function App() {
  const [concept, setConcept] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ExplanationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    const fetchLogo = async () => {
      try {
        const url = await generateLogo();
        setLogoUrl(url);
      } catch (err) {
        console.error("Failed to generate logo:", err);
      }
    };
    fetchLogo();

    // Initialize AudioContext on first user interaction
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!concept.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);
    setIsPlaying(false);
    audioBufferRef.current = null;

    try {
      const data = await explainConcept(concept);
      setResult(data);
    } catch (err) {
      console.error(err);
      setError('Failed to generate explanation. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const toggleAudio = async () => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }

      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      if (isPlaying) {
        if (audioSourceRef.current) {
          audioSourceRef.current.stop();
          audioSourceRef.current = null;
        }
        setIsPlaying(false);
        return;
      }

      if (!result?.audioUrl) {
        setError("No audio data available for this lesson.");
        return;
      }

      // If we don't have the buffer yet, fetch and decode it
      if (!audioBufferRef.current) {
        const response = await fetch(result.audioUrl);
        const arrayBuffer = await response.arrayBuffer();
        audioBufferRef.current = await audioContextRef.current.decodeAudioData(arrayBuffer);
      }

      // Create and start source
      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBufferRef.current;
      source.connect(audioContextRef.current.destination);
      source.onended = () => setIsPlaying(false);
      source.start(0);
      audioSourceRef.current = source;
      setIsPlaying(true);

    } catch (err) {
      console.error("Audio playback error:", err);
      setError("Audio playback failed. Your browser might be restricting audio in this environment.");
      setIsPlaying(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12 flex flex-col items-center"
      >
        <div className="relative mb-6">
          {logoUrl ? (
            <motion.div
              animate={{ 
                boxShadow: ["0 0 0px rgba(0,255,0,0)", "0 0 20px rgba(0,255,0,0.3)", "0 0 0px rgba(0,255,0,0)"]
              }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="w-32 h-32 rounded-3xl overflow-hidden shadow-2xl border-2 border-brand-200"
            >
              <img src={logoUrl} alt="LearnScape Lab.ai Logo" className="w-full h-full object-cover" />
            </motion.div>
          ) : (
            <div className="inline-flex items-center justify-center p-3 bg-brand-200 rounded-2xl">
              <BookOpen className="w-8 h-8 text-brand-700" />
            </div>
          )}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute -top-4 -right-4 text-brand-400 opacity-50"
          >
            <Sparkles className="w-8 h-8" />
          </motion.div>
        </div>
        
        <h1 className="text-4xl sm:text-6xl font-serif font-bold text-brand-950 mb-3 tracking-tight flex items-center gap-2">
          <span>LearnScape</span>
          <span className="font-light text-brand-600">Lab.ai</span>
        </h1>
        <p className="text-lg text-brand-600 max-w-2xl mx-auto font-medium">
          The Future of Multimodal Knowledge Exploration
        </p>
      </motion.header>

      {/* Search Bar */}
      <motion.form 
        onSubmit={handleSearch}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-2xl mb-12"
      >
        <div className="relative group">
          <input
            type="text"
            value={concept}
            onChange={(e) => setConcept(e.target.value)}
            placeholder="What would you like to learn about today?"
            className="w-full px-6 py-5 bg-white border-2 border-brand-200 rounded-3xl text-lg focus:outline-none focus:border-brand-500 transition-all shadow-sm group-hover:shadow-md pr-16"
            disabled={loading}
          />
          <button
            type="submit"
            disabled={loading || !concept.trim()}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-3 bg-brand-950 text-white rounded-2xl hover:bg-brand-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <ArrowRight className="w-6 h-6" />}
          </button>
        </div>
      </motion.form>

      {/* Error Message */}
      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="bg-red-50 border border-red-200 text-red-700 px-6 py-4 rounded-2xl mb-8 max-w-2xl w-full"
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Loading State */}
      {loading && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center gap-4 text-brand-600 mt-12"
        >
          <div className="relative">
            <Loader2 className="w-12 h-12 animate-spin text-brand-500" />
            <Sparkles className="w-6 h-6 absolute -top-2 -right-2 text-brand-400 animate-pulse" />
          </div>
          <p className="font-medium animate-pulse">Preparing your personalized lesson...</p>
        </motion.div>
      )}

      {/* Results */}
      <AnimatePresence>
        {result && !loading && (
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            {/* Left Column: Illustration & Audio */}
            <div className="space-y-8">
              <section className="bg-white p-6 rounded-3xl shadow-sm border border-brand-100 overflow-hidden">
                <div className="flex items-center gap-2 mb-4 text-brand-600 font-semibold uppercase text-xs tracking-wider">
                  <ImageIcon className="w-4 h-4" />
                  Visual Representation
                </div>
                {result.imageUrl ? (
                  <motion.img 
                    initial={{ opacity: 0, scale: 1.05 }}
                    animate={{ opacity: 1, scale: 1 }}
                    src={result.imageUrl} 
                    alt={concept}
                    className="w-full aspect-video object-cover rounded-2xl shadow-inner bg-brand-50"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full aspect-video bg-brand-50 rounded-2xl flex items-center justify-center text-brand-400 italic">
                    Illustration not available
                  </div>
                )}
              </section>

              <section className="bg-brand-950 text-white p-8 rounded-3xl shadow-lg relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                  <Volume2 className="w-24 h-24" />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center gap-2 mb-6 text-brand-300 font-semibold uppercase text-xs tracking-wider">
                    <Volume2 className="w-4 h-4" />
                    Audio Narration
                  </div>
                  <div className="flex items-center gap-6">
                    <button 
                      onClick={toggleAudio}
                      className="w-16 h-16 flex items-center justify-center bg-white text-brand-950 rounded-full hover:scale-105 transition-transform shadow-xl"
                    >
                      {isPlaying ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
                    </button>
                    <div>
                      <h3 className="text-xl font-serif font-semibold mb-1">Listen to Explanation</h3>
                      <p className="text-brand-300 text-sm">Narrated by AI Teacher Assistant</p>
                    </div>
                  </div>
                </div>
              </section>
            </div>

            {/* Right Column: Text Explanation */}
            <section className="bg-white p-8 sm:p-10 rounded-3xl shadow-sm border border-brand-100">
              <div className="flex items-center gap-2 mb-6 text-brand-600 font-semibold uppercase text-xs tracking-wider">
                <BookOpen className="w-4 h-4" />
                Detailed Explanation
              </div>
              <div className="markdown-body prose prose-brand max-w-none">
                <Markdown>{result.text}</Markdown>
              </div>
            </section>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="mt-auto pt-12 text-brand-400 text-sm font-medium">
        Powered by Gemini AI • Multimodal Education
      </footer>
    </div>
  );
}
